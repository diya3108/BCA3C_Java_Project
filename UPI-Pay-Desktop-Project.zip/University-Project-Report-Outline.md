# UPI Pay Desktop — University Project Report Outline

1. **Introduction** — Context for digital payment workflows and this local simulation.
2. **Objectives** — Demonstrate account creation, authentication, simulated balances, transfers, and transaction records.
3. **Problem Statement** — Need for a safe academic desktop demo of payment concepts without connecting to a bank.
4. **Proposed System** — Java Swing application with SQLite persistence and atomic local transfers.
5. **Requirements** — Java runtime, desktop OS, user registration, local database, and simulated payment disclaimer.
6. **System Architecture** — Swing UI, Java service/logic methods, JDBC/SQLite persistence; include a component diagram.
7. **Database Design** — `users` and `tx` tables, keys, balance constraints, and sender/receiver relationships; include an ER diagram.
8. **Module Descriptions** — Registration/Login; Simulated Account; Send; Receive; History; Security/PIN; Dashboard/Reports.
9. **Screenshots** — Login, registration, dashboard, Add Demo Money, transfer confirmation, history, and PIN screen.
10. **Testing** — Add test cases and actual outcomes for validation, balances, transfers, persistence, and account isolation. Clearly distinguish executed tests from planned tests.
11. **Limitations** — No real payment connectivity; local-only data; demo-grade security and reporting.
12. **Conclusion and Future Work** — Summarize the demo and propose richer filters, edit flows, audit records, and automated service tests.

